import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  HeartPulse, 
  LayoutDashboard, 
  Apple, 
  Droplet, 
  Activity, 
  Scale, 
  BrainCircuit, 
  UtensilsCrossed, 
  ChefHat, 
  MessageSquareHeart, 
  TrendingUp, 
  UserCircle,
  Menu,
  X,
  Sparkles,
  Info
} from 'lucide-react';

// Import Types
import { UserProfile, MealLog, WaterLog, ActivityLog, ForumPost, Recipe, ChatMessage, Comment, UserAccount } from './types';

// Import child components
import Dashboard from './components/Dashboard';
import FoodTracker from './components/FoodTracker';
import WaterTracker from './components/WaterTracker';
import ActivityTracker from './components/ActivityTracker';
import BMICalculator from './components/BMICalculator';
import AICoach from './components/AICoach';
import MealPlanner from './components/MealPlanner';
import Recipes from './components/Recipes';
import CommunityForum from './components/CommunityForum';
import Analytics from './components/Analytics';
import ThemeToggle from './components/ThemeToggle';
import Profile from './components/Profile';
import HealthTips from './components/HealthTips';
import AboutProject from './components/AboutProject';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import DeveloperConsole from './components/DeveloperConsole';

export default function App() {
  // --- States ---
  const [activeTab, setActiveTab] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  // --- Registered Users DB ---
  const [registeredUsers, setRegisteredUsers] = useState<UserAccount[]>(() => {
    const saved = localStorage.getItem('nutritracker_users');
    if (saved) return JSON.parse(saved);
    
    // Seed system users
    const initialUsers: UserAccount[] = [
      {
        email: "persia@example.com",
        password: "persia",
        role: "customer",
        profile: {
          name: "Persia",
          email: "persia@example.com",
          age: 20,
          gender: "Female",
          height: 165,
          weight: 58,
          dailyCalorieGoal: 1900,
          dailyWaterGoal: 3000,
          joinDate: "June 2026"
        }
      },
      {
        email: "admin@nutri.com",
        password: "admin123",
        role: "admin",
        profile: {
          name: "Administrator Team",
          email: "admin@nutri.com",
          age: 35,
          gender: "Non-binary",
          height: 175,
          weight: 70,
          dailyCalorieGoal: 0,
          dailyWaterGoal: 0,
          joinDate: "June 2026"
        }
      },
      {
        email: "dev@nutri.com",
        password: "dev123",
        role: "developer",
        profile: {
          name: "Lead System Developer",
          email: "dev@nutri.com",
          age: 28,
          gender: "Male",
          height: 180,
          weight: 75,
          dailyCalorieGoal: 0,
          dailyWaterGoal: 0,
          joinDate: "June 2026"
        }
      }
    ];
    localStorage.setItem('nutritracker_users', JSON.stringify(initialUsers));
    return initialUsers;
  });

  // --- Active Logged-In User Session ---
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem('nutritracker_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Profile database state linked with active user session
  const [profile, setProfile] = useState<UserProfile>(() => {
    const savedCurrentUser = localStorage.getItem('nutritracker_current_user');
    if (savedCurrentUser) {
      const u = JSON.parse(savedCurrentUser);
      return u.profile;
    }
    return {
      name: "Persia",
      email: "persia@example.com",
      age: 20,
      gender: "Female",
      height: 165,
      weight: 58,
      dailyCalorieGoal: 1900,
      dailyWaterGoal: 3000,
      joinDate: "June 2026"
    };
  });

  // Meal logs
  const [meals, setMeals] = useState<MealLog[]>(() => {
    const saved = localStorage.getItem('meals');
    if (saved) return JSON.parse(saved);
    const today = new Date();
    // Seed high-quality initial data
    return [
      {
        id: "meal-1",
        name: "Whole-wheat Oatmeal with Blueberries",
        mealType: "Breakfast",
        quantity: "1 bowl",
        calories: 220,
        timestamp: new Date(today.setHours(8, 15, 0, 0)).toISOString()
      },
      {
        id: "meal-2",
        name: "Grilled Chicken Breast with Quinoa",
        mealType: "Lunch",
        quantity: "1 plate",
        calories: 450,
        timestamp: new Date(today.setHours(13, 0, 0, 0)).toISOString()
      },
      {
        id: "meal-3",
        name: "Dynamic Whey Protein Shake",
        mealType: "Snacks",
        quantity: "1 scoop",
        calories: 140,
        timestamp: new Date(today.setHours(16, 45, 0, 0)).toISOString()
      }
    ];
  });

  // Water logs
  const [waterLogs, setWaterLogs] = useState<WaterLog[]>(() => {
    const saved = localStorage.getItem('water');
    if (saved) return JSON.parse(saved);
    const today = new Date();
    return [
      {
        id: "water-1",
        amount: 250,
        timestamp: new Date(today.setHours(8, 30, 0, 0)).toISOString()
      },
      {
        id: "water-2",
        amount: 500,
        timestamp: new Date(today.setHours(11, 0, 0, 0)).toISOString()
      },
      {
        id: "water-3",
        amount: 500,
        timestamp: new Date(today.setHours(14, 15, 0, 0)).toISOString()
      },
      {
        id: "water-4",
        amount: 250,
        timestamp: new Date(today.setHours(17, 30, 0, 0)).toISOString()
      }
    ];
  });

  // Exercise logs
  const [activities, setActivities] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem('activities');
    if (saved) return JSON.parse(saved);
    const today = new Date();
    return [
      {
        id: "act-1",
        activity: "Brisk Outdoor Jogging",
        duration: 30,
        caloriesBurned: 280,
        timestamp: new Date(today.setHours(7, 30, 0, 0)).toISOString()
      },
      {
        id: "act-2",
        activity: "Stretching & Yoga Flow",
        duration: 15,
        caloriesBurned: 60,
        timestamp: new Date(today.setHours(18, 0, 0, 0)).toISOString()
      }
    ];
  });

  // Community Feed Posts State
  const [posts, setPosts] = useState<ForumPost[]>(() => {
    const saved = localStorage.getItem('forum_posts');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: "post-1",
        username: "Priya Sharma",
        time: "2 hours ago",
        content: "💧 I started drinking 3 litres of water daily and noticed a huge improvement in my energy levels and skin clarity. Truly transformative!",
        likes: 18,
        likedByMe: false,
        comments: [
          { id: "com-1", username: "Rahul Patel", content: "Awesome work! Getting hydrated changes everything.", timestamp: new Date().toISOString() }
        ]
      },
      {
        id: "post-2",
        username: "Rahul Patel",
        time: "5 hours ago",
        content: "🏃 Walking 10,000 steps every day helped me lose 4 kg in two months. No heavy gym required, consistency is the key!",
        likes: 25,
        likedByMe: false,
        comments: []
      },
      {
        id: "post-3",
        username: "Aisha Khan",
        time: "1 day ago",
        content: "🍎 Replacing chips with fresh strawberries and apples during evening hunger pangs helped reduce my junk food cravings.",
        likes: 31,
        likedByMe: false,
        comments: []
      }
    ];
  });

  // Shared Recipes State
  const [recipes, setRecipes] = useState<Recipe[]>(() => {
    const saved = localStorage.getItem('recipes');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: "rec-1",
        name: "Oats Vegetable Upma",
        ingredients: "Roasted Oats, chopped carrots, green peas, green chilies, mustard seeds, turmeric powder, coriander leaves",
        instructions: "1. Roast oats in dry pan. 2. Sauté mustard seeds, chilies and carrots in 1 tsp olive oil. 3. Add hot water, turmeric, salt and bring to a boil. 4. Mix roasted oats, cook on low heat till water absorbs. Serve hot.",
        calories: 150,
        likes: 12,
        likedByMe: false,
        creator: "Aisha Khan"
      },
      {
        id: "rec-2",
        name: "Cool Citrus Berry Salad",
        ingredients: "Sliced strawberries, blueberries, seedless orange segments, dynamic fresh mint leaves, lime juice, 1 tsp honey",
        instructions: "1. Mix all fruits cleanly in a large bowl. 2. Whisk fresh lime juice and honey together. 3. Drizzle over salad dressing. 4. Top with chopped fresh mint leaves. Serve chilled.",
        calories: 120,
        likes: 8,
        likedByMe: false,
        creator: "Priya Sharma"
      },
      {
        id: "rec-3",
        name: "Power Peanut Banana Smoothie",
        ingredients: "1 glass skimmed milk, 1 medium banana, 1 tablespoon natural peanut butter, 2 tablespoons steel-cut oats",
        instructions: "1. Toss oats into blender, pulse until fine powder. 2. Append banana, peanut butter, and cool skimmed milk. 3. Blend at high speed till completely creamy. Enjoy post-workout.",
        calories: 250,
        likes: 19,
        likedByMe: false,
        creator: "Rahul Patel"
      }
    ];
  });

  // Chat Coach AI logs state
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('chat_history');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: "chat-welcome",
        sender: "bot",
        text: "Hello! I'm your advanced AI Nutritionist Coach powered by Gemini. Ask me any clinical questions regarding proteins, complex carbs, safe weight deficits, or balanced meal options!",
        timestamp: new Date().toISOString()
      }
    ];
  });
  const [chatLoading, setChatLoading] = useState(false);

  // --- Sync storage ---
  useEffect(() => {
    localStorage.setItem('profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('meals', JSON.stringify(meals));
  }, [meals]);

  useEffect(() => {
    localStorage.setItem('water', JSON.stringify(waterLogs));
  }, [waterLogs]);

  useEffect(() => {
    localStorage.setItem('activities', JSON.stringify(activities));
  }, [activities]);

  useEffect(() => {
    localStorage.setItem('forum_posts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('recipes', JSON.stringify(recipes));
  }, [recipes]);

  useEffect(() => {
    localStorage.setItem('chat_history', JSON.stringify(chatHistory));
  }, [chatHistory]);

  // Dark mode effect
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  // --- Session Handlers ---
  const handleLoginSuccess = (account: UserAccount) => {
    setCurrentUser(account);
    setProfile(account.profile);
    localStorage.setItem('nutritracker_current_user', JSON.stringify(account));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('nutritracker_current_user');
  };

  const handleRegisterUser = (newAccount: UserAccount) => {
    const updated = [...registeredUsers, newAccount];
    setRegisteredUsers(updated);
    localStorage.setItem('nutritracker_users', JSON.stringify(updated));
  };

  const handleUpdateProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
    if (currentUser) {
      const updatedUser = { ...currentUser, profile: newProfile };
      setCurrentUser(updatedUser);
      localStorage.setItem('nutritracker_current_user', JSON.stringify(updatedUser));
      
      const updatedUsers = registeredUsers.map(u => 
        u.email.toLowerCase() === currentUser.email.toLowerCase() ? updatedUser : u
      );
      setRegisteredUsers(updatedUsers);
      localStorage.setItem('nutritracker_users', JSON.stringify(updatedUsers));
    }
  };

  const handleSeedDemoData = () => {
    const today = new Date();
    const demoAccounts: UserAccount[] = [
      {
        email: "persia@example.com",
        password: "persia",
        role: "customer",
        profile: {
          name: "Persia",
          email: "persia@example.com",
          age: 20,
          gender: "Female",
          height: 165,
          weight: 58,
          dailyCalorieGoal: 1900,
          dailyWaterGoal: 3000,
          joinDate: "June 2026"
        }
      },
      {
        email: "priya@example.com",
        password: "priya",
        role: "customer",
        profile: {
          name: "Priya Sharma",
          email: "priya@example.com",
          age: 24,
          gender: "Female",
          height: 162,
          weight: 54,
          dailyCalorieGoal: 1800,
          dailyWaterGoal: 2500,
          joinDate: "April 2026"
        }
      },
      {
        email: "rahul@example.com",
        password: "rahul",
        role: "customer",
        profile: {
          name: "Rahul Patel",
          email: "rahul@example.com",
          age: 29,
          gender: "Male",
          height: 178,
          weight: 82,
          dailyCalorieGoal: 2400,
          dailyWaterGoal: 3500,
          joinDate: "May 2026"
        }
      },
      {
        email: "aisha@example.com",
        password: "aisha",
        role: "customer",
        profile: {
          name: "Aisha Khan",
          email: "aisha@example.com",
          age: 22,
          gender: "Female",
          height: 168,
          weight: 60,
          dailyCalorieGoal: 2100,
          dailyWaterGoal: 3000,
          joinDate: "January 2026"
        }
      },
      {
        email: "admin@nutri.com",
        password: "admin123",
        role: "admin",
        profile: {
          name: "Administrator Team",
          email: "admin@nutri.com",
          age: 35,
          gender: "Non-binary",
          height: 175,
          weight: 70,
          dailyCalorieGoal: 0,
          dailyWaterGoal: 0,
          joinDate: "June 2026"
        }
      },
      {
        email: "dev@nutri.com",
        password: "dev123",
        role: "developer",
        profile: {
          name: "Lead System Developer",
          email: "dev@nutri.com",
          age: 28,
          gender: "Male",
          height: 180,
          weight: 75,
          dailyCalorieGoal: 0,
          dailyWaterGoal: 0,
          joinDate: "June 2026"
        }
      }
    ];

    setRegisteredUsers(demoAccounts);
    localStorage.setItem('nutritracker_users', JSON.stringify(demoAccounts));

    const demoMeals: MealLog[] = [
      { id: "m-p1", name: "Whole-wheat Oatmeal with Blueberries", mealType: "Breakfast", quantity: "1 bowl", calories: 220, timestamp: today.toISOString(), userEmail: "persia@example.com" },
      { id: "m-pr1", name: "Smashed Avocado Toast with Eggs", mealType: "Breakfast", quantity: "2 slices", calories: 340, timestamp: today.toISOString(), userEmail: "priya@example.com" },
      { id: "m-r1", name: "Protein Shake with Peanut Butter", mealType: "Breakfast", quantity: "1 shake", calories: 410, timestamp: today.toISOString(), userEmail: "rahul@example.com" },
      { id: "m-a1", name: "Green Matcha Bowl with Chia", mealType: "Breakfast", quantity: "1 bowl", calories: 280, timestamp: today.toISOString(), userEmail: "aisha@example.com" },
      { id: "m-p2", name: "Grilled Chicken Breast with Quinoa", mealType: "Lunch", quantity: "1 plate", calories: 450, timestamp: today.toISOString(), userEmail: "persia@example.com" },
      { id: "m-pr2", name: "Tofu Summer Rolls with Peanut Dip", mealType: "Lunch", quantity: "3 rolls", calories: 320, timestamp: today.toISOString(), userEmail: "priya@example.com" },
      { id: "m-r2", name: "Double Beef Patty Salad Wrap", mealType: "Lunch", quantity: "1 wrap", calories: 650, timestamp: today.toISOString(), userEmail: "rahul@example.com" },
      { id: "m-p3", name: "Salmon with Asparagus", mealType: "Dinner", quantity: "1 fillet", calories: 390, timestamp: today.toISOString(), userEmail: "persia@example.com" },
      { id: "m-pr3", name: "Lentil Soup with Kale", mealType: "Dinner", quantity: "1 bowl", calories: 250, timestamp: today.toISOString(), userEmail: "priya@example.com" },
      { id: "m-a2", name: "Paneer Tikka with Roti", mealType: "Dinner", quantity: "1 plate", calories: 510, timestamp: today.toISOString(), userEmail: "aisha@example.com" }
    ];

    const demoWater: WaterLog[] = [
      { id: "w-p1", amount: 250, timestamp: today.toISOString(), userEmail: "persia@example.com" },
      { id: "w-p2", amount: 500, timestamp: today.toISOString(), userEmail: "persia@example.com" },
      { id: "w-pr1", amount: 500, timestamp: today.toISOString(), userEmail: "priya@example.com" },
      { id: "w-pr2", amount: 750, timestamp: today.toISOString(), userEmail: "priya@example.com" },
      { id: "w-pr3", amount: 500, timestamp: today.toISOString(), userEmail: "priya@example.com" },
      { id: "w-r1", amount: 1000, timestamp: today.toISOString(), userEmail: "rahul@example.com" },
      { id: "w-r2", amount: 1000, timestamp: today.toISOString(), userEmail: "rahul@example.com" },
      { id: "w-a1", amount: 500, timestamp: today.toISOString(), userEmail: "aisha@example.com" },
      { id: "w-a2", amount: 500, timestamp: today.toISOString(), userEmail: "aisha@example.com" },
      { id: "w-a3", amount: 250, timestamp: today.toISOString(), userEmail: "aisha@example.com" }
    ];

    const demoActivities: ActivityLog[] = [
      { id: "a-p1", activity: "Brisk Outdoor Jogging", duration: 30, caloriesBurned: 280, timestamp: today.toISOString(), userEmail: "persia@example.com" },
      { id: "a-pr1", activity: "Vinyasa Yoga Practice", duration: 45, caloriesBurned: 180, timestamp: today.toISOString(), userEmail: "priya@example.com" },
      { id: "a-r1", activity: "Heavy Powerlifting Session", duration: 60, caloriesBurned: 450, timestamp: today.toISOString(), userEmail: "rahul@example.com" },
      { id: "a-a1", activity: "HIIT Tabata Cardio", duration: 25, caloriesBurned: 310, timestamp: today.toISOString(), userEmail: "aisha@example.com" }
    ];

    setMeals(demoMeals);
    setWaterLogs(demoWater);
    setActivities(demoActivities);

    localStorage.setItem('meals', JSON.stringify(demoMeals));
    localStorage.setItem('water', JSON.stringify(demoWater));
    localStorage.setItem('activities', JSON.stringify(demoActivities));
  };

  const handleClearDb = () => {
    localStorage.clear();
    setMeals([]);
    setWaterLogs([]);
    setActivities([]);
    setRegisteredUsers([]);
    setCurrentUser(null);
    window.location.reload();
  };

  // --- CRUD Callback Handlers ---

  const handleUpdateMetrics = (w: number, h: number) => {
    const updated = {
      ...profile,
      weight: w,
      height: h
    };
    handleUpdateProfile(updated);
  };

  const handleAddMeal = (newMeal: Omit<MealLog, 'id' | 'timestamp'>) => {
    const mealItem: MealLog = {
      ...newMeal,
      id: `meal-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userEmail: currentUser?.email || 'persia@example.com'
    };
    setMeals(prev => [mealItem, ...prev]);
  };

  const handleDeleteMeal = (id: string) => {
    setMeals(prev => prev.filter(m => m.id !== id));
  };

  const handleAddWater = (amount: number) => {
    const waterItem: WaterLog = {
      id: `water-${Date.now()}`,
      amount,
      timestamp: new Date().toISOString(),
      userEmail: currentUser?.email || 'persia@example.com'
    };
    setWaterLogs(prev => [waterItem, ...prev]);
  };

  const handleAddActivity = (newAct: Omit<ActivityLog, 'id' | 'timestamp'>) => {
    const actItem: ActivityLog = {
      ...newAct,
      id: `act-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userEmail: currentUser?.email || 'persia@example.com'
    };
    setActivities(prev => [actItem, ...prev]);
  };

  const handleDeleteActivity = (id: string) => {
    setActivities(prev => prev.filter(a => a.id !== id));
  };

  const handleAddPost = (content: string) => {
    const newPost: ForumPost = {
      id: `post-${Date.now()}`,
      username: profile.name,
      time: "Just now",
      content,
      likes: 0,
      likedByMe: false,
      comments: []
    };
    setPosts(prev => [newPost, ...prev]);
  };

  const handleLikePost = (id: string) => {
    setPosts(prev => prev.map(p => {
      if (p.id === id) {
        const liked = !p.likedByMe;
        return {
          ...p,
          likes: liked ? p.likes + 1 : p.likes - 1,
          likedByMe: liked
        };
      }
      return p;
    }));
  };

  const handleAddComment = (postId: string, content: string) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        const comItem: Comment = {
          id: `com-${Date.now()}`,
          username: profile.name,
          content,
          timestamp: new Date().toISOString()
        };
        return {
          ...p,
          comments: [...p.comments, comItem]
        };
      }
      return p;
    }));
  };

  const handleAddRecipe = (recipeData: Omit<Recipe, 'id' | 'likes' | 'likedByMe' | 'creator'>) => {
    const recipeItem: Recipe = {
      ...recipeData,
      id: `rec-${Date.now()}`,
      likes: 0,
      likedByMe: false,
      creator: profile.name
    };
    setRecipes(prev => [recipeItem, ...prev]);
  };

  const handleLikeRecipe = (id: string) => {
    setRecipes(prev => prev.map(r => {
      if (r.id === id) {
        const liked = !r.likedByMe;
        return {
          ...r,
          likes: liked ? r.likes + 1 : r.likes - 1,
          likedByMe: liked
        };
      }
      return r;
    }));
  };

  const handleSendMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: `chat-usr-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toISOString()
    };
    setChatHistory(prev => [...prev, userMsg]);
    setChatLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: text })
      });

      if (!response.ok) {
        throw new Error('Chat API returned error status');
      }

      const data = await response.json();
      const botMsg: ChatMessage = {
        id: `chat-bot-${Date.now()}`,
        sender: 'bot',
        text: data.text || "I processed your request, but could not construct a text response.",
        timestamp: new Date().toISOString()
      };
      setChatHistory(prev => [...prev, botMsg]);
    } catch (error) {
      console.error('Chat error:', error);
      const errMsg: ChatMessage = {
        id: `chat-err-${Date.now()}`,
        sender: 'bot',
        text: "I apologize, my AI connection is currently experiencing latency. Let's try again in a few moments!",
        timestamp: new Date().toISOString()
      };
      setChatHistory(prev => [...prev, errMsg]);
    } finally {
      setChatLoading(false);
    }
  };

  // --- Sidebar Links ---
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, color: 'text-emerald-500' },
    { id: 'food', label: 'Food Log', icon: Apple, color: 'text-orange-500' },
    { id: 'water', label: 'Hydration', icon: Droplet, color: 'text-cyan-500' },
    { id: 'activity', label: 'Exercise', icon: Activity, color: 'text-emerald-500' },
    { id: 'bmi', label: 'BMI Analysis', icon: Scale, color: 'text-rose-500' },
    { id: 'coach', label: 'AI Health Coach', icon: BrainCircuit, color: 'text-indigo-500' },
    { id: 'planner', label: 'Meal Planner', icon: UtensilsCrossed, color: 'text-cyan-600' },
    { id: 'recipes', label: 'Shared Recipes', icon: ChefHat, color: 'text-emerald-600' },
    { id: 'forum', label: 'Wellness Forum', icon: MessageSquareHeart, color: 'text-teal-500' },
    { id: 'analytics', label: 'Analytics', icon: TrendingUp, color: 'text-indigo-600' },
    { id: 'profile', label: 'My Profile', icon: UserCircle, color: 'text-amber-500' },
    { id: 'tips', label: 'Health Tips', icon: Sparkles, color: 'text-yellow-550' },
    { id: 'about', label: 'About Project', icon: Info, color: 'text-blue-550' }
  ];

  const handleTabSwitch = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
  };

  // --- Filter logs for active customer ---
  const userMeals = meals.filter(m => m.userEmail === currentUser?.email || (!m.userEmail && currentUser?.email === 'persia@example.com'));
  const userWaterLogs = waterLogs.filter(w => w.userEmail === currentUser?.email || (!w.userEmail && currentUser?.email === 'persia@example.com'));
  const userActivities = activities.filter(a => a.userEmail === currentUser?.email || (!a.userEmail && currentUser?.email === 'persia@example.com'));

  if (!currentUser) {
    return (
      <Login 
        onLoginSuccess={handleLoginSuccess}
        registeredUsers={registeredUsers}
        onRegisterUser={handleRegisterUser}
      />
    );
  }

  if (currentUser.role === 'admin') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-850 dark:text-slate-100 transition-colors duration-300">
        <header className="h-16 px-4 md:px-6 border-b border-slate-200 dark:border-slate-850 bg-white/75 dark:bg-slate-900/75 backdrop-blur-md flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <HeartPulse className="w-6 h-6 text-emerald-500 animate-pulse" />
            <span className="font-display font-extrabold text-base tracking-tight text-slate-900 dark:text-white">
              NutriTracker <span className="text-orange-500 font-bold">Admin Portal</span>
            </span>
          </div>
          <ThemeToggle darkMode={darkMode} onToggle={() => setDarkMode(!darkMode)} />
        </header>
        <main className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
          <AdminDashboard 
            adminUser={currentUser}
            allUsers={registeredUsers}
            allMeals={meals}
            allWater={waterLogs}
            allActivities={activities}
            onLogout={handleLogout}
          />
        </main>
      </div>
    );
  }

  if (currentUser.role === 'developer') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 transition-colors duration-300">
        <header className="h-16 px-4 md:px-6 border-b border-slate-850 bg-slate-900/75 backdrop-blur-md flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <HeartPulse className="w-6 h-6 text-emerald-500 animate-pulse" />
            <span className="font-mono font-extrabold text-sm tracking-tight text-white">
              nutritracker_db@root_console
            </span>
          </div>
          <ThemeToggle darkMode={darkMode} onToggle={() => setDarkMode(!darkMode)} />
        </header>
        <main className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
          <DeveloperConsole 
            devUser={currentUser}
            allUsers={registeredUsers}
            allMeals={meals}
            allWater={waterLogs}
            allActivities={activities}
            onLogout={handleLogout}
            onSeedDemoData={handleSeedDemoData}
            onClearDb={handleClearDb}
          />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex transition-colors duration-300">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0 select-none">
        {/* Brand Header */}
        <div className="h-16 px-6 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2">
          <HeartPulse className="w-7 h-7 text-emerald-500 animate-pulse" />
          <span className="font-display font-extrabold text-lg text-slate-800 dark:text-white tracking-tight shrink-0">
            NutriTracker <span className="text-[10px] text-emerald-500 font-semibold uppercase block -mt-1 tracking-wider">3rd-Year Core</span>
          </span>
        </div>

        {/* Navigation links */}
        <nav className="flex-1 py-6 px-4 space-y-1.5 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabSwitch(item.id)}
                className={`w-full px-3.5 py-2.5 rounded-xl text-left text-sm font-semibold flex items-center gap-3 transition-all cursor-pointer ${
                  active 
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm' 
                    : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-850/60'
                }`}
              >
                <Icon className={`w-4.5 h-4.5 ${active ? item.color : 'text-slate-400 dark:text-slate-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Desktop Profile Status */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/20 space-y-2">
          <div className="flex items-center gap-3">
            <UserCircle className="w-9 h-9 text-slate-450 dark:text-slate-500 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{profile.name}</p>
              <p className="text-[10px] text-slate-400 font-semibold tracking-wider truncate uppercase">Customer Session</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="w-full py-1.5 px-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-850 dark:hover:bg-slate-800 text-[10px] text-rose-500 hover:text-rose-650 font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
          >
            <span>Secure Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Navbar */}
        <header className="h-16 px-4 md:px-6 border-b border-slate-200 dark:border-slate-800 bg-white/75 dark:bg-slate-900/75 backdrop-blur-md sticky top-0 z-40 flex items-center justify-between gap-4 select-none">
          {/* Left: Mobile Menu Trigger or Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 cursor-pointer"
              title="Open menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <span className="lg:hidden flex items-center gap-1.5 font-display font-black text-slate-850 dark:text-white text-base">
              <HeartPulse className="w-5.5 h-5.5 text-emerald-500 animate-pulse" />
              <span>NutriTracker</span>
            </span>
          </div>

          {/* Right actions: Light/Dark toggle + profile */}
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Academics Project ID</p>
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">CS-3009 Final Submission</p>
            </div>
            
            <ThemeToggle darkMode={darkMode} onToggle={() => setDarkMode(!darkMode)} />
          </div>
        </header>

        {/* Mobile Navigation Drawer Overlay */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <>
              {/* Backdrop */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                onClick={() => setMobileMenuOpen(false)}
                className="fixed inset-0 bg-black z-40 lg:hidden"
              />
              
              {/* Drawer Container */}
              <motion.aside 
                initial={{ x: '-100%' }}
                animate={{ x: 0 }}
                exit={{ x: '-100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="fixed inset-y-0 left-0 w-64 z-50 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 p-6 flex flex-col justify-between shadow-2xl lg:hidden"
              >
                <div>
                  <div className="flex items-center justify-between pb-6 border-b border-slate-150 dark:border-slate-800">
                    <span className="font-display font-black text-slate-800 dark:text-white flex items-center gap-1.5">
                      <HeartPulse className="w-6 h-6 text-emerald-500" />
                      <span>NutriTracker</span>
                    </span>
                    <button 
                      onClick={() => setMobileMenuOpen(false)}
                      className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
                      title="Close menu"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <nav className="py-6 space-y-1">
                    {menuItems.map((item) => {
                      const Icon = item.icon;
                      const active = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => handleTabSwitch(item.id)}
                          className={`w-full px-3.5 py-2.5 rounded-xl text-left text-sm font-semibold flex items-center gap-3 cursor-pointer ${
                            active 
                              ? 'bg-slate-100 dark:bg-slate-800 text-slate-950 dark:text-white' 
                              : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-850/60'
                          }`}
                        >
                          <Icon className={`w-4.5 h-4.5 ${active ? item.color : 'text-slate-400 dark:text-slate-500'}`} />
                          <span>{item.label}</span>
                        </button>
                      );
                    })}
                  </nav>
                </div>

                <div className="pt-4 border-t border-slate-150 dark:border-slate-850 flex flex-col gap-3">
                  <div className="flex items-center gap-3">
                    <UserCircle className="w-9 h-9 text-slate-450 dark:text-slate-500 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{profile.name}</p>
                      <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Customer Session</p>
                    </div>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="w-full py-2 px-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-850 dark:hover:bg-slate-800 text-xs text-rose-500 hover:text-rose-650 font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>Secure Logout</span>
                  </button>
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Content Page Section wrapper */}
        <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-y-auto">
          <div className="max-w-6xl mx-auto">
            {/* Direct custom tab rendering with motion layouts */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25 }}
              >
                {activeTab === 'dashboard' && (
                  <Dashboard 
                    profile={profile}
                    meals={userMeals}
                    waterLogs={userWaterLogs}
                    activities={userActivities}
                    onNavigate={handleTabSwitch}
                    onQuickAddWater={handleAddWater}
                  />
                )}

                {activeTab === 'food' && (
                  <FoodTracker 
                    meals={userMeals}
                    profile={profile}
                    onAddMeal={handleAddMeal}
                    onDeleteMeal={handleDeleteMeal}
                  />
                )}

                {activeTab === 'water' && (
                  <WaterTracker 
                    waterLogs={userWaterLogs}
                    profile={profile}
                    onAddWater={handleAddWater}
                  />
                )}

                {activeTab === 'activity' && (
                  <ActivityTracker 
                    activities={userActivities}
                    onAddActivity={handleAddActivity}
                    onDeleteActivity={handleDeleteActivity}
                  />
                )}

                {activeTab === 'bmi' && (
                  <BMICalculator 
                    profile={profile}
                    onUpdateMetrics={handleUpdateMetrics}
                  />
                )}

                {activeTab === 'coach' && (
                  <AICoach 
                    chatHistory={chatHistory}
                    onSendMessage={handleSendMessage}
                    loading={chatLoading}
                  />
                )}

                {activeTab === 'planner' && (
                  <MealPlanner 
                    profile={profile}
                  />
                )}

                {activeTab === 'recipes' && (
                  <Recipes 
                    recipes={recipes}
                    profile={profile}
                    onAddRecipe={handleAddRecipe}
                    onLikeRecipe={handleLikeRecipe}
                  />
                )}

                {activeTab === 'forum' && (
                  <CommunityForum 
                    posts={posts}
                    profile={profile}
                    onAddPost={handleAddPost}
                    onLikePost={handleLikePost}
                    onAddComment={handleAddComment}
                  />
                )}

                {activeTab === 'analytics' && (
                  <Analytics 
                    profile={profile}
                    meals={userMeals}
                    waterLogs={userWaterLogs}
                    activities={userActivities}
                  />
                )}

                {activeTab === 'profile' && (
                  <Profile 
                    profile={profile}
                    onUpdateProfile={handleUpdateProfile}
                  />
                )}

                {activeTab === 'tips' && (
                  <HealthTips />
                )}

                {activeTab === 'about' && (
                  <AboutProject />
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}
