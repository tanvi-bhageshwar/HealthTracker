import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Users, 
  Search, 
  TrendingUp, 
  Apple, 
  Droplet, 
  Activity, 
  Scale, 
  UserCircle, 
  Eye, 
  Download, 
  CheckCircle,
  Clock,
  LogOut
} from 'lucide-react';
import { UserAccount, MealLog, WaterLog, ActivityLog } from '../types';

interface AdminDashboardProps {
  adminUser: UserAccount;
  allUsers: UserAccount[];
  allMeals: MealLog[];
  allWater: WaterLog[];
  allActivities: ActivityLog[];
  onLogout: () => void;
}

export default function AdminDashboard({ 
  adminUser, 
  allUsers, 
  allMeals, 
  allWater, 
  allActivities, 
  onLogout 
}: AdminDashboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUserEmail, setSelectedUserEmail] = useState<string | null>(null);

  // Filter users by search query
  const customersOnly = allUsers.filter(u => u.role === 'customer');
  const filteredCustomers = customersOnly.filter(u => 
    u.profile.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Selected User's detailed logs
  const selectedUser = allUsers.find(u => u.email === selectedUserEmail);
  
  // Custom cast logs that belong to the selected user
  // (We use a safe check: either userEmail is explicitly set, or if they are legacy logs, they belong to persia@example.com)
  const getUserMeals = (email: string) => {
    return allMeals.filter(m => (m as any).userEmail === email || (!(m as any).userEmail && email === 'persia@example.com'));
  };

  const getUserWater = (email: string) => {
    return allWater.filter(w => (w as any).userEmail === email || (!(w as any).userEmail && email === 'persia@example.com'));
  };

  const getUserActivities = (email: string) => {
    return allActivities.filter(a => (a as any).userEmail === email || (!(a as any).userEmail && email === 'persia@example.com'));
  };

  // Compute System Statistics
  const totalCustomers = customersOnly.length;
  const avgAge = totalCustomers > 0 
    ? Math.round(customersOnly.reduce((acc, curr) => acc + curr.profile.age, 0) / totalCustomers) 
    : 0;
  const avgWeight = totalCustomers > 0 
    ? Math.round(customersOnly.reduce((acc, curr) => acc + curr.profile.weight, 0) / totalCustomers) 
    : 0;

  return (
    <div className="space-y-6" id="admin-dashboard">
      
      {/* Top Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-8 relative overflow-hidden shadow-lg border border-slate-800">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <ShieldCheck className="w-48 h-48" />
        </div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/20 border border-orange-500/30 text-orange-400 text-xs font-bold uppercase tracking-wider mb-3">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin Management Interface</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black font-display tracking-tight">
              Hello, Administrator <span className="text-orange-400">{adminUser.profile.name}</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              You are logged in with role security clearance level 2. View all user profiles, registration details, logs, and audit trails.
            </p>
          </div>

          <button
            onClick={onLogout}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-xs font-bold uppercase tracking-wider text-slate-300 hover:text-white rounded-xl border border-slate-700/80 transition-all flex items-center justify-center gap-2 cursor-pointer self-start md:self-center"
          >
            <LogOut className="w-4 h-4" />
            <span>Secure Logout</span>
          </button>
        </div>
      </div>

      {/* Admin Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex items-center gap-4">
          <div className="p-3.5 bg-orange-100 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400 rounded-xl">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Registered Clients</p>
            <p className="text-2xl font-black text-slate-900 dark:text-white">{totalCustomers}</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex items-center gap-4">
          <div className="p-3.5 bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-xl">
            <Scale className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Average Weight</p>
            <p className="text-2xl font-black text-slate-900 dark:text-white">{avgWeight} kg</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex items-center gap-4">
          <div className="p-3.5 bg-cyan-100 dark:bg-cyan-950/40 text-cyan-600 dark:text-cyan-400 rounded-xl">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Average Age</p>
            <p className="text-2xl font-black text-slate-900 dark:text-white">{avgAge} yrs</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex items-center gap-4">
          <div className="p-3.5 bg-indigo-100 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-xl">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">System Status</p>
            <p className="text-2xl font-black text-emerald-500">Live</p>
          </div>
        </div>
      </div>

      {/* Main Grid split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 1/3: Users directory */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm flex flex-col h-[600px]">
          <div className="pb-4 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">Registered Customer Accounts</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search by name or email..."
                className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto py-4 space-y-2.5">
            {filteredCustomers.length > 0 ? (
              filteredCustomers.map(user => {
                const isSelected = selectedUserEmail === user.email;
                return (
                  <button
                    key={user.email}
                    onClick={() => setSelectedUserEmail(user.email)}
                    className={`w-full text-left p-3 rounded-xl border flex items-center gap-3 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-orange-50/50 dark:bg-orange-950/15 border-orange-500/30 shadow-sm'
                        : 'bg-slate-55/10 dark:bg-slate-900/40 border-slate-200 dark:border-slate-850 hover:bg-slate-50'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400 flex items-center justify-center shrink-0 font-bold text-sm">
                      {user.profile.name.charAt(0).toUpperCase()}
                    </div>
                    
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-slate-850 dark:text-slate-200 truncate">{user.profile.name}</p>
                      <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
                      <div className="flex gap-1.5 mt-1">
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500">
                          {user.profile.age} yrs
                        </span>
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500">
                          {user.profile.weight} kg
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="text-center py-12 text-slate-400">
                <p className="text-xs">No registered customer accounts found.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right 2/3: Selected user logs and profiles */}
        <div className="lg:col-span-2 space-y-6">
          {selectedUser ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
              
              {/* User Profile Header */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <UserCircle className="w-12 h-12 text-slate-450 dark:text-slate-500" />
                  <div>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white">{selectedUser.profile.name}</h3>
                    <p className="text-xs text-slate-400">Email: {selectedUser.email} &bull; Registered on {selectedUser.profile.joinDate}</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <div className="px-3 py-1 rounded-xl bg-orange-50 dark:bg-orange-950/30 text-orange-600 dark:text-orange-400 text-xs font-bold border border-orange-100 dark:border-orange-900/30">
                    {selectedUser.profile.gender}
                  </div>
                  <div className="px-3 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold border border-emerald-100 dark:border-emerald-900/30">
                    Age: {selectedUser.profile.age}
                  </div>
                </div>
              </div>

              {/* Targets and Physical specs summary */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-150 dark:border-slate-850/80">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Weight</p>
                  <p className="text-base font-bold text-slate-900 dark:text-white mt-0.5">{selectedUser.profile.weight} kg</p>
                </div>
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-150 dark:border-slate-850/80">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Height</p>
                  <p className="text-base font-bold text-slate-900 dark:text-white mt-0.5">{selectedUser.profile.height} cm</p>
                </div>
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-150 dark:border-slate-850/80">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Calorie Target</p>
                  <p className="text-base font-bold text-orange-500 mt-0.5">{selectedUser.profile.dailyCalorieGoal} kcal</p>
                </div>
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-150 dark:border-slate-850/80">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Water Target</p>
                  <p className="text-base font-bold text-cyan-500 mt-0.5">{selectedUser.profile.dailyWaterGoal} ml</p>
                </div>
              </div>

              {/* Logs visualizer tab details */}
              <div className="space-y-4 pt-2">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  <span>Audit Logs & Submissions</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Meal logs */}
                  <div className="bg-slate-50/50 dark:bg-slate-950/20 p-4 border border-slate-150 dark:border-slate-850 rounded-2xl space-y-3">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-orange-500 uppercase tracking-wider pb-2 border-b border-slate-200 dark:border-slate-800">
                      <Apple className="w-4 h-4" />
                      <span>Meal Log ({getUserMeals(selectedUser.email).length})</span>
                    </div>

                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {getUserMeals(selectedUser.email).length > 0 ? (
                        getUserMeals(selectedUser.email).map(meal => (
                          <div key={meal.id} className="p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-150 dark:border-slate-850 text-[11px] leading-relaxed">
                            <p className="font-semibold text-slate-850 dark:text-slate-200 truncate">{meal.name}</p>
                            <p className="text-slate-400 font-bold mt-0.5">{meal.calories} kcal &bull; {meal.mealType}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-[10px] text-slate-400 italic text-center py-4">No meal records found.</p>
                      )}
                    </div>
                  </div>

                  {/* Water logs */}
                  <div className="bg-slate-50/50 dark:bg-slate-950/20 p-4 border border-slate-150 dark:border-slate-850 rounded-2xl space-y-3">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-500 uppercase tracking-wider pb-2 border-b border-slate-200 dark:border-slate-800">
                      <Droplet className="w-4 h-4" />
                      <span>Water Log ({getUserWater(selectedUser.email).length})</span>
                    </div>

                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {getUserWater(selectedUser.email).length > 0 ? (
                        getUserWater(selectedUser.email).map(w => (
                          <div key={w.id} className="p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-150 dark:border-slate-850 text-[11px] flex justify-between">
                            <span className="font-semibold text-slate-850 dark:text-slate-200">{w.amount} ml</span>
                            <span className="text-slate-400">{new Date(w.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                        ))
                      ) : (
                        <p className="text-[10px] text-slate-400 italic text-center py-4">No fluid logs registered.</p>
                      )}
                    </div>
                  </div>

                  {/* Activity logs */}
                  <div className="bg-slate-50/50 dark:bg-slate-950/20 p-4 border border-slate-150 dark:border-slate-850 rounded-2xl space-y-3">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-500 uppercase tracking-wider pb-2 border-b border-slate-200 dark:border-slate-800">
                      <Activity className="w-4 h-4" />
                      <span>Exercise ({getUserActivities(selectedUser.email).length})</span>
                    </div>

                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {getUserActivities(selectedUser.email).length > 0 ? (
                        getUserActivities(selectedUser.email).map(act => (
                          <div key={act.id} className="p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-150 dark:border-slate-850 text-[11px] leading-relaxed">
                            <p className="font-semibold text-slate-850 dark:text-slate-200 truncate">{act.activity}</p>
                            <p className="text-slate-400 font-bold mt-0.5">{act.duration} mins &bull; {act.caloriesBurned} kcal</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-[10px] text-slate-400 italic text-center py-4">No activities logged.</p>
                      )}
                    </div>
                  </div>

                </div>
              </div>

            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-12 shadow-sm text-center">
              <UserCircle className="w-16 h-16 text-slate-300 dark:text-slate-700 mx-auto mb-4" />
              <h3 className="font-bold text-slate-900 dark:text-white">No Client Selected</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                Please click on a customer from the sidebar directory list on the left to inspect their profiles, demographic registrations, and specific food/water logs.
              </p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
