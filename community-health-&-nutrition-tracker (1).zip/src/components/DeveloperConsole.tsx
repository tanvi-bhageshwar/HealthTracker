import React, { useState } from 'react';
import { 
  Cpu, 
  Database, 
  Users, 
  Droplet, 
  Apple, 
  Activity, 
  DatabaseBackup, 
  Search, 
  Terminal, 
  LogOut, 
  Sparkles,
  Layers,
  LineChart,
  HardDrive
} from 'lucide-react';
import { UserAccount, MealLog, WaterLog, ActivityLog } from '../types';

interface DeveloperConsoleProps {
  devUser: UserAccount;
  allUsers: UserAccount[];
  allMeals: MealLog[];
  allWater: WaterLog[];
  allActivities: ActivityLog[];
  onLogout: () => void;
  onSeedDemoData: () => void;
  onClearDb: () => void;
}

export default function DeveloperConsole({
  devUser,
  allUsers,
  allMeals,
  allWater,
  allActivities,
  onLogout,
  onSeedDemoData,
  onClearDb
}: DeveloperConsoleProps) {
  const [activeTab, setActiveTab] = useState<'registered' | 'water_logs' | 'all_logs' | 'diagnostics'>('registered');
  const [searchQuery, setSearchQuery] = useState('');

  // Filtering lists
  const filteredUsers = allUsers.filter(u => 
    u.profile.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Retrieve water log with User Details
  const getExtendedWaterLogs = () => {
    return allWater.map(w => {
      const user = allUsers.find(u => u.email === (w as any).userEmail);
      return {
        ...w,
        userName: user ? user.profile.name : 'Persia (Default)',
        userEmail: (w as any).userEmail || 'persia@example.com'
      };
    }).filter(w => 
      w.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.userEmail.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  const getExtendedMealLogs = () => {
    return allMeals.map(m => {
      const user = allUsers.find(u => u.email === (m as any).userEmail);
      return {
        ...m,
        userName: user ? user.profile.name : 'Persia (Default)',
        userEmail: (m as any).userEmail || 'persia@example.com'
      };
    }).filter(m => 
      m.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  const totalWaterIntake = allWater.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="space-y-6" id="developer-console">
      {/* Dev Header */}
      <div className="bg-slate-950 text-slate-100 rounded-3xl p-6 md:p-8 relative overflow-hidden shadow-2xl border border-slate-850">
        <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
          <Terminal className="w-56 h-56" />
        </div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-400 text-xs font-mono font-bold uppercase tracking-wider mb-3">
              <Cpu className="w-3.5 h-3.5" />
              <span>Root Developer Console v3.1</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black font-mono tracking-tight text-white">
              developer@nutri_sh ~ <span className="text-indigo-400">{devUser.profile.name}</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1 max-w-xl font-mono">
              Access level: Superuser. Inspect, verify, and monitor the entire database state, registered accounts, logs, and fluid/calories tracking logs.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={onSeedDemoData}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-bold uppercase rounded-xl transition-all flex items-center gap-1.5 shadow-md shadow-indigo-500/10 cursor-pointer"
              title="Seeds multiple pre-filled active users (Priya, Rahul, Aisha) with complete tracking metrics"
            >
              <DatabaseBackup className="w-4 h-4" />
              <span>Seed Multi-User Demo</span>
            </button>

            <button
              onClick={onLogout}
              className="px-3.5 py-2 bg-slate-900 hover:bg-slate-850 text-xs font-bold uppercase tracking-wider text-slate-350 hover:text-white rounded-xl border border-slate-800 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>

      {/* Real-time Hardware Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/40 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl font-mono">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Total Registrations</p>
          <p className="text-xl font-bold text-white mt-1 flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-400" />
            <span>{allUsers.length} Users</span>
          </p>
        </div>

        <div className="bg-slate-900/40 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl font-mono">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Total Hydration Logs</p>
          <p className="text-xl font-bold text-cyan-400 mt-1 flex items-center gap-2">
            <Droplet className="w-5 h-5" />
            <span>{allWater.length} logs</span>
          </p>
        </div>

        <div className="bg-slate-900/40 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl font-mono">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Aggregate Hydration Vol</p>
          <p className="text-xl font-bold text-emerald-400 mt-1 flex items-center gap-2">
            <HardDrive className="w-5 h-5" />
            <span>{(totalWaterIntake / 1000).toFixed(1)} L</span>
          </p>
        </div>

        <div className="bg-slate-900/40 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl font-mono">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Active API Node</p>
          <p className="text-xl font-bold text-indigo-400 mt-1 flex items-center gap-2">
            <Cpu className="w-5 h-5" />
            <span>Gemini-Flash</span>
          </p>
        </div>
      </div>

      {/* Internal Navigation Subtabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-1.5 overflow-x-auto pb-px font-mono text-xs">
        {[
          { id: 'registered', label: 'Registered Database', icon: Users },
          { id: 'water_logs', label: 'Master Water Audit (Intakes)', icon: Droplet },
          { id: 'all_logs', label: 'Master Food logs', icon: Apple },
          { id: 'diagnostics', label: 'System Schemas & Raw State', icon: Terminal }
        ].map((sub) => {
          const Icon = sub.icon;
          const active = activeTab === sub.id;
          return (
            <button
              key={sub.id}
              onClick={() => { setActiveTab(sub.id as any); setSearchQuery(''); }}
              className={`flex items-center gap-2 py-3 px-4 font-semibold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                active 
                  ? 'border-indigo-500 text-indigo-500 bg-indigo-50/10' 
                  : 'border-transparent text-slate-450 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{sub.label}</span>
            </button>
          );
        })}
      </div>

      {/* Central Search filter for active log selection */}
      {activeTab !== 'diagnostics' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search master registries (email, name, role)..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
            />
          </div>
          
          <div className="text-xs text-slate-400 font-mono">
            Filtered matches: <strong className="text-indigo-400">{
              activeTab === 'registered' ? filteredUsers.length :
              activeTab === 'water_logs' ? getExtendedWaterLogs().length :
              getExtendedMealLogs().length
            }</strong> records
          </div>
        </div>
      )}

      {/* Tab Render Container */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm">
        
        {/* TAB 1: REGISTERED USER DATABASE */}
        {activeTab === 'registered' && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-sm font-bold text-slate-900 dark:text-white">Master Registration Registry</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-indigo-50 dark:bg-indigo-950 text-indigo-500 font-bold border border-indigo-200 dark:border-indigo-900">
                DB_USER_TABLE_STATUS: SECURE
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-150 dark:border-slate-850 rounded-2xl">
              <table className="w-full text-left font-mono text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-150 dark:border-slate-850">
                    <th className="py-3 px-4">Register Name</th>
                    <th className="py-3 px-4">Clearance Role</th>
                    <th className="py-3 px-4">Registered Email</th>
                    <th className="py-3 px-4">Physical Stats</th>
                    <th className="py-3 px-4">Daily Cal/Water Goals</th>
                    <th className="py-3 px-4">Join Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 dark:divide-slate-850">
                  {filteredUsers.map((user) => (
                    <tr key={user.email} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/20 text-slate-800 dark:text-slate-250">
                      <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${user.role === 'developer' ? 'bg-indigo-500' : user.role === 'admin' ? 'bg-orange-500' : 'bg-emerald-500'}`} />
                        <span>{user.profile.name}</span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase ${
                          user.role === 'developer' ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400' :
                          user.role === 'admin' ? 'bg-orange-100 text-orange-600 dark:bg-orange-950/40 dark:text-orange-400' :
                          'bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400'
                        }`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-450">{user.email}</td>
                      <td className="py-3.5 px-4 text-slate-500">
                        {user.role === 'customer' ? `${user.profile.weight}kg / ${user.profile.height}cm / ${user.profile.age}yrs` : 'N/A (System)'}
                      </td>
                      <td className="py-3.5 px-4 font-semibold">
                        {user.role === 'customer' ? (
                          <span className="text-indigo-500">{user.profile.dailyCalorieGoal} kcal / {user.profile.dailyWaterGoal} ml</span>
                        ) : 'N/A'}
                      </td>
                      <td className="py-3.5 px-4 text-slate-400">{user.profile.joinDate}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: MASTER WATER AUDIT */}
        {activeTab === 'water_logs' && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-mono text-sm font-bold text-slate-900 dark:text-white">Fluid Intake Audit Trail</h3>
                <p className="text-[11px] text-slate-400 font-mono">Consolidated telemetry data representing water logged by each practitioner.</p>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-cyan-50 dark:bg-cyan-950 text-cyan-500 font-bold border border-cyan-200 dark:border-cyan-900">
                LOGS_WATER_STREAM_CONNECTED
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-150 dark:border-slate-850 rounded-2xl">
              <table className="w-full text-left font-mono text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-150 dark:border-slate-850">
                    <th className="py-3 px-4">Log ID</th>
                    <th className="py-3 px-4">Practitioner Name</th>
                    <th className="py-3 px-4">User Email</th>
                    <th className="py-3 px-4">Log Timestamp</th>
                    <th className="py-3 px-4 text-right">Intake Amount (ml)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 dark:divide-slate-850">
                  {getExtendedWaterLogs().length > 0 ? (
                    getExtendedWaterLogs().map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/20 text-slate-800 dark:text-slate-250">
                        <td className="py-3.5 px-4 text-slate-400 font-bold">{log.id}</td>
                        <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                          <Droplet className="w-3.5 h-3.5 text-cyan-500" />
                          <span>{log.userName}</span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-450">{log.userEmail}</td>
                        <td className="py-3.5 px-4 text-slate-450">{new Date(log.timestamp).toLocaleString()}</td>
                        <td className="py-3.5 px-4 text-right font-bold text-cyan-600 dark:text-cyan-400">
                          {log.amount} ml
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400">
                        No hydration logs present in system database. Use the "Seed Multi-User Demo" button to create pre-filled histories!
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: FOOD LOGS */}
        {activeTab === 'all_logs' && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-mono text-sm font-bold text-slate-900 dark:text-white">Macro Calorie Intake Auditing</h3>
                <p className="text-[11px] text-slate-400 font-mono">Consolidated journal containing details of all meals consumed system-wide.</p>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-orange-50 dark:bg-orange-950 text-orange-500 font-bold border border-orange-200 dark:border-orange-900">
                LOGS_CAL_STREAM_CONNECTED
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-150 dark:border-slate-850 rounded-2xl">
              <table className="w-full text-left font-mono text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-150 dark:border-slate-850">
                    <th className="py-3 px-4">Log ID</th>
                    <th className="py-3 px-4">User</th>
                    <th className="py-3 px-4">Meal Description</th>
                    <th className="py-3 px-4">Meal Type</th>
                    <th className="py-3 px-4">Quantity</th>
                    <th className="py-3 px-4">Timestamp</th>
                    <th className="py-3 px-4 text-right">Energy (kcal)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 dark:divide-slate-850">
                  {getExtendedMealLogs().length > 0 ? (
                    getExtendedMealLogs().map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/20 text-slate-800 dark:text-slate-250">
                        <td className="py-3.5 px-4 text-slate-400 font-bold">{log.id}</td>
                        <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                          {log.userName} ({log.userEmail})
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-slate-700 dark:text-slate-250 truncate max-w-[200px]">
                          {log.name}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-bold">
                            {log.mealType}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-450">{log.quantity}</td>
                        <td className="py-3.5 px-4 text-slate-450">{new Date(log.timestamp).toLocaleString()}</td>
                        <td className="py-3.5 px-4 text-right font-bold text-orange-500">
                          {log.calories} kcal
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        No food log entries found in master database.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: RAW STATE INSPECTOR */}
        {activeTab === 'diagnostics' && (
          <div className="space-y-6 animate-fade-in font-mono text-xs">
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Relational DDL & State Management</h3>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                The application maps system-wide state cleanly in memory, syncing each user’s session logs dynamically. See active structural metadata details below:
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left Column: DB Commands / State schema info */}
              <div className="space-y-4">
                <div className="p-4 bg-slate-950 text-indigo-400 rounded-2xl border border-slate-850 space-y-2">
                  <p className="font-bold text-emerald-500 flex items-center gap-2">
                    <Layers className="w-4 h-4" />
                    <span>Database Engine Specs</span>
                  </p>
                  <div className="space-y-1 text-[11px] text-slate-350">
                    <p>&bull; DBMS: LocalStorage Persistent Partition Engine</p>
                    <p>&bull; Active Connection String: LOCAL_MEMORY_SYNC://nutri_db</p>
                    <p>&bull; Total LocalStorage Bytes: {JSON.stringify(localStorage).length} characters</p>
                    <p>&bull; User Accounts Table Capacity: 50 accounts</p>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-850 space-y-3">
                  <span className="font-bold text-[11px] text-slate-400 uppercase tracking-wider block">Dangerous Actions</span>
                  <div className="flex gap-2">
                    <button
                      onClick={onClearDb}
                      className="px-3 py-1.5 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-lg text-[10px] cursor-pointer"
                    >
                      Delete All Data / Hard Reset
                    </button>
                    <button
                      onClick={onSeedDemoData}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-indigo-400 border border-indigo-500/20 rounded-lg text-[10px] font-bold cursor-pointer"
                    >
                      Seed Demo Entities
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column: RAW JSON INSPECTOR */}
              <div className="space-y-2">
                <span className="font-bold text-[11px] text-slate-400 uppercase tracking-wider">State Database Registry Inspection</span>
                <div className="bg-slate-950 text-slate-300 p-4 rounded-2xl max-h-72 overflow-y-auto text-[10px] leading-relaxed border border-slate-850">
                  <pre className="text-emerald-400">{JSON.stringify({
                    database_status: "CONNECTED",
                    registered_users_count: allUsers.length,
                    water_logs_telemetry: allWater,
                    meal_logs_telemetry: allMeals,
                    exercise_logs_telemetry: allActivities
                  }, null, 2)}</pre>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
