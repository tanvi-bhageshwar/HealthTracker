import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  HeartPulse, 
  Lock, 
  Mail, 
  User, 
  ShieldCheck, 
  Cpu, 
  Users, 
  Eye, 
  EyeOff, 
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { UserAccount, UserProfile } from '../types';

interface LoginProps {
  onLoginSuccess: (account: UserAccount) => void;
  registeredUsers: UserAccount[];
  onRegisterUser: (newAccount: UserAccount) => void;
}

export default function Login({ onLoginSuccess, registeredUsers, onRegisterUser }: LoginProps) {
  const [isRegister, setIsRegister] = useState(false);
  const [role, setRole] = useState<'customer' | 'admin' | 'developer'>('customer');
  
  // Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [securityPasscode, setSecurityPasscode] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Demographics (Registration only)
  const [age, setAge] = useState(25);
  const [gender, setGender] = useState('Female');
  const [height, setHeight] = useState(170);
  const [weight, setWeight] = useState(65);

  const handleRoleChange = (selectedRole: 'customer' | 'admin' | 'developer') => {
    setRole(selectedRole);
    setErrorMsg('');
    setSecurityPasscode('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (isRegister) {
      // --- Registration Logic ---
      if (!name || !email || !password) {
        setErrorMsg('Please fill out all required fields.');
        return;
      }

      // Check if user already exists
      const exists = registeredUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (exists) {
        setErrorMsg('An account with this email address already exists.');
        return;
      }

      // Security Passcode Validation for Admin & Developer
      if (role === 'admin' && securityPasscode !== 'admin123') {
        setErrorMsg('Invalid Admin Security Passcode. Try "admin123" for testing!');
        return;
      }

      if (role === 'developer' && securityPasscode !== 'dev123') {
        setErrorMsg('Invalid Developer Security Passcode. Try "dev123" for testing!');
        return;
      }

      // Construct profile
      const newProfile: UserProfile = {
        name,
        email,
        age,
        gender,
        height,
        weight,
        dailyCalorieGoal: role === 'customer' ? 2000 : 0,
        dailyWaterGoal: role === 'customer' ? 3000 : 0,
        joinDate: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
      };

      const newAccount: UserAccount = {
        email,
        password,
        role,
        profile: newProfile
      };

      onRegisterUser(newAccount);
      onLoginSuccess(newAccount);

    } else {
      // --- Login Logic ---
      if (!email || !password) {
        setErrorMsg('Please enter both your email and password.');
        return;
      }

      const foundUser = registeredUsers.find(
        u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
      );

      if (!foundUser) {
        setErrorMsg('Invalid email or password. Please try again.');
        return;
      }

      // Check if user is logging into the selected role
      if (foundUser.role !== role) {
        setErrorMsg(`This account is registered as a ${foundUser.role.toUpperCase()}, not a ${role.toUpperCase()}.`);
        return;
      }

      onLoginSuccess(foundUser);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 select-none transition-colors duration-300">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center items-center gap-2.5">
          <div className="p-3 bg-emerald-500 rounded-2xl shadow-md shadow-emerald-500/20 text-white animate-pulse">
            <HeartPulse className="w-8 h-8" />
          </div>
          <span className="font-display font-black text-2xl text-slate-900 dark:text-white tracking-tight">
            NutriTracker <span className="text-emerald-500">Workspace</span>
          </span>
        </div>
        <h2 className="mt-6 text-center text-xl font-bold text-slate-850 dark:text-slate-100">
          {isRegister ? 'Create your medical-grade tracking space' : 'Welcome back to your health profile'}
        </h2>
        <p className="mt-2 text-center text-xs text-slate-400">
          Advanced Clinical Tracking, Forum, and Gemini Coaching System.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-xl">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 py-8 px-4 shadow-xl shadow-slate-100 dark:shadow-none rounded-3xl sm:px-10">
          
          {/* 3-way Role Selector tab buttons */}
          <div className="mb-6">
            <label className="block text-xs font-extrabold text-slate-400 uppercase tracking-widest text-center mb-3">
              Choose Security Clearance / Role
            </label>
            <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 dark:bg-slate-950 rounded-2xl border border-slate-200/50 dark:border-slate-850">
              <button
                type="button"
                onClick={() => handleRoleChange('customer')}
                className={`py-2 px-3 rounded-xl text-xs font-semibold flex flex-col md:flex-row items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  role === 'customer'
                    ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Customer</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleChange('admin')}
                className={`py-2 px-3 rounded-xl text-xs font-semibold flex flex-col md:flex-row items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  role === 'admin'
                    ? 'bg-white dark:bg-slate-800 text-orange-600 dark:text-orange-400 shadow-sm'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Admin</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleChange('developer')}
                className={`py-2 px-3 rounded-xl text-xs font-semibold flex flex-col md:flex-row items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  role === 'developer'
                    ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'
                }`}
              >
                <Cpu className="w-4 h-4" />
                <span>Developer</span>
              </button>
            </div>
          </div>

          {/* Mode toggle (Login vs Register) */}
          <div className="flex border-b border-slate-100 dark:border-slate-800 mb-6 justify-center gap-6">
            <button
              type="button"
              onClick={() => { setIsRegister(false); setErrorMsg(''); }}
              className={`pb-3 font-semibold text-sm border-b-2 transition-all cursor-pointer ${
                !isRegister 
                  ? 'border-emerald-500 text-emerald-500' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Log In
            </button>
            <button
              type="button"
              onClick={() => { setIsRegister(true); setErrorMsg(''); }}
              className={`pb-3 font-semibold text-sm border-b-2 transition-all cursor-pointer ${
                isRegister 
                  ? 'border-emerald-500 text-emerald-500' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Register New Account
            </button>
          </div>

          {errorMsg && (
            <div className="mb-4 p-3 bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 rounded-xl flex items-start gap-2 border border-rose-100 dark:border-rose-900/40 text-xs font-medium">
              <AlertCircle className="w-4.5 h-4.5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Name Input (Registration only) */}
            {isRegister && (
              <div>
                <label className="block text-xs font-bold text-slate-450 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                  Full Name / Username
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-sm text-slate-800 dark:text-slate-150 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                    required
                  />
                </div>
              </div>
            )}

            {/* Email Address */}
            <div>
              <label className="block text-xs font-bold text-slate-450 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-sm text-slate-800 dark:text-slate-150 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-bold text-slate-450 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-sm text-slate-800 dark:text-slate-150 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Admin or Developer Passcode requirement */}
            {(role === 'admin' || role === 'developer') && (
              <div className="bg-slate-50 dark:bg-slate-950/40 border border-slate-200/50 dark:border-slate-850 p-4 rounded-2xl space-y-3">
                <div className="flex items-start gap-2">
                  <HelpCircle className="w-4 h-4 text-emerald-500 mt-0.5" />
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Access to {role.toUpperCase()} roles requires verification. 
                    For academic testing, please use <strong className="text-emerald-500 dark:text-emerald-400">{role === 'admin' ? 'admin123' : 'dev123'}</strong> as the security passcode!
                  </p>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-450 dark:text-slate-400 uppercase tracking-widest mb-1">
                    System Security Passcode
                  </label>
                  <input
                    type="password"
                    value={securityPasscode}
                    onChange={e => setSecurityPasscode(e.target.value)}
                    placeholder={`Enter ${role} passcode`}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-150 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>
            )}

            {/* Demographics inputs (Registration only for Customer role) */}
            {isRegister && role === 'customer' && (
              <div className="border-t border-slate-100 dark:border-slate-800/80 pt-4 mt-2 space-y-3">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block">
                  Optional Demographics Metrics
                </span>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-1">AGE (YEARS)</label>
                    <input
                      type="number"
                      value={age}
                      onChange={e => setAge(Number(e.target.value))}
                      className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs"
                      min="1"
                      max="120"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-1">GENDER</label>
                    <select
                      value={gender}
                      onChange={e => setGender(e.target.value)}
                      className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs"
                    >
                      <option value="Female">Female</option>
                      <option value="Male">Male</option>
                      <option value="Non-binary">Non-binary</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-1">HEIGHT (CM)</label>
                    <input
                      type="number"
                      value={height}
                      onChange={e => setHeight(Number(e.target.value))}
                      className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs"
                      min="50"
                      max="250"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-1">WEIGHT (KG)</label>
                    <input
                      type="number"
                      value={weight}
                      onChange={e => setWeight(Number(e.target.value))}
                      className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs"
                      min="10"
                      max="300"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Submit button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl text-sm shadow-md shadow-emerald-500/15 hover:shadow-emerald-500/25 transition-all cursor-pointer"
              >
                {isRegister ? `Register as ${role.toUpperCase()}` : `Login as ${role.toUpperCase()}`}
              </button>
            </div>
          </form>

          {/* Quick instructions for demo */}
          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-center">
            <p className="text-[10px] text-slate-400 font-medium">
              Demo logins: <span className="font-bold text-slate-600 dark:text-slate-300">persia@example.com</span> (Password: <span className="font-bold text-slate-600 dark:text-slate-300">persia</span>)
            </p>
          </div>

        </div>
      </div>
    </div>
  );
}
